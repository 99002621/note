# Git - Source version management

* [Workflow Syntax](Workflow_Syntax.pdf)

# References
https://www.codeproject.com/Articles/1214409/Learn-YAML-in-five-minutes
https://docs.github.com/en/free-pro-team@latest/actions
https://docs.github.com/en/free-pro-team@latest/actions/reference/events-that-trigger-workflows#webhook-events