
# 1. Activity
* Major defects and recalls in Medical Devices
    - incident 
    - cause (why?)
    - impact (effects)
    - outcome (Loss )
* UML
* SISMl
Team Activity 3 - 
Analyse and document your understanding of Agile 
Manifesto , Principles, Roles, Ceremonies, Artifacts, Tools
Next Few Days - Run agile method by rotating the roles, Ceremonies etc

* Beverage Dispenser by V Model
* docuement the Delta changes and Adapt the Changes in the Micro Project of c++
* Git Setup and Badges of C++
* Aigle Model for Beverage Dispenser
    - user stroies
    - epic
    - themes




# 2. Learning Report Wishlist
* Results Graphical Representaion
* References



# SDLC Procdedure 
1. Introduction
    
2. Research(Aging vs Costing)
    - ageing (product features for different years)
        - costing (price related parameters)

3. About Product 
    - Define Product

4. SWOT Analysis

5. Requirements
    * ID and Disc
    * High Level - Features
    * Low level to acceess that functional

6. Design
    * UML Diagrams
        - Structural ()
        - Behaviaral (Componet level,sequence diagram)

7. Test Plan(Requirement,Scenario,)
    - Integration Test PLan 
        * test id
        * descriptiom
        * expected input
        * expected output

    - Unit Test Plan

## Challanges 
* Power Backup
* Traceability 




