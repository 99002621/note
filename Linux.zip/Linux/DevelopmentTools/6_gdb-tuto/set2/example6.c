#include<stdio.h>

//TODO: memory APIs

int main(int argc, char* argv[]) {
  
  return 0;
}
