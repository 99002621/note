# Hands-on & Discussion
* Implicit rules
* Built-in variables : CC, CXX, LD, AS
* Built-in flag vars : CFLAGS, CXXFLAGS, LDFLAGS, ASFLAGS
