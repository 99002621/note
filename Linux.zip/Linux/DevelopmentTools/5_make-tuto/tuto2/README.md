# Hands-on & Discussion
* Meaning of special variables $@, $^, $<
