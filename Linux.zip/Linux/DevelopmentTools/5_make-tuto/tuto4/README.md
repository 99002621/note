# Hands-on & Discussion
* Pattern based rules
* User variables
