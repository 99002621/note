# Outline

* Who initiated Linux Kernel Development?
* Who initiated GNU Software Development?
* What is the full form of GNU?
* What is GNU/Linux?
* Do Linux is Free and Open Source software?
* What are the various Open Source Licensing Models, e.g. GPL v3?
* What is the full form of GPL?
* Identify some popular Linux Distributions
* Identify some popular Linux Desktop Environments
* Identify some end user applications in Linux (Alternatives to Windows apps)
* Identify the Programming support in Linux

> [Click Here](README.md) to go back to main page
