# Examples 
* Sender example [code](mqsender.c)
* Receive example [code](mqrcvr.c)
