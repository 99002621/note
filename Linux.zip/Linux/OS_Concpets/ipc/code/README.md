# Examples
* POSIX Message Queues [code](posix_msgqueues)
* POSIX Shared Memory 
