# Classes and Objects

* Datamembers in class are private by default 

## Initializer List
    Initializer List is used in initializing the data members of a class in constructors

    Syntax:
     <className>::className(): data1(inp1),data2(inp2){}
   
## Reference Links
* https://www.geeksforgeeks.org/when-do-we-use-initializer-list-in-c/


