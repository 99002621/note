## Memory in C
https://www.geeksforgeeks.org/memory-layout-of-c-program/