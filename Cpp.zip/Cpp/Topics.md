# Study Topics
* google test framework
* Object Oriented Concepts
classes & objects and able to write programs
Operator Overloading concepts and able to write programs
Inheritance & Polymorphic Concepts (Virtual functions,DynamicBinding, Abstract classes) and able to write programs
templates and able to write programs
writing test cases with Unit testing framework likeGoogleTest
code quality measures (code style, staticanalysis, avoiding memory leaks etc) 
Data Structures (concepts) 
knowledge on STL containers & iterators 
Cpp Insights (Non Trivial classes, Copy Elison, ExplicitConstructors,Overloading Special Operators, RTTI Concepts and CastingTechniques etc) 
STL containers & algorithms for given scenarios (Banking,Library etc) 
complex programs with suitable business logic forgiven scenarios (Banking, Library, Data Analysis etc) 


Week 2

virtual memory
API
Virtual Functions....
Overriding
Upcasting and downcasting
based declaration and based on object
pure virtual functions(abstract class without no objects) 
allows functionality description
pointers and references for the derived classes
virtual tables
virtual destructor
RTTI...
dynamic and static cast 
typeid
function objects
friend functions

Hash Tables
unordered_set
unorder_map
unorder_multiset
unordered_multimap
prevent copy using private copy

STL
map list vectors pairs sets
Vectors, Maps, List, Sets, Array 
c++ 11 Updates
subscript operator(STL)

#include function

-------------------------------------------------------------------------
Week 1

Modular programming
Unit Testing( Google Test )
Code Quality - clang /astyle -Coding Standards 
Static analysis (cpp check,valgirin)
runtime and Linker error
doxygen documentation generation

Basic C++
Copy constructer
pointers
operator
function overloading
Name mangling
Statics in all the context
"insights on the C++"
operator overloading and virtual functions
initializer list
extern 'c'
c and c++ linkage
Extern storage classes 
Initializer list
Trivial and non-trivial types
Rule of 3 or Zero
Templates
User defined conversation 
 Return value optimization.
virtual void area()=0;
Inheritance


Code .text
idata .data
udata .bss
read only .rodata
dynamic heap
stack

Data structures and Algorithms
Time and Space complexity
Arrays,Linked List, Stack,Queue,Trees.

 git, Source Code Management, Version Control System, Repositories
"git-bash" for source code management 
git clone repository link
git branches
git status
git add
git config
git commit
git push


